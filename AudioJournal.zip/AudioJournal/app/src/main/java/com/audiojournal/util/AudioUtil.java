package com.audiojournal.util;

import android.content.Context;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AudioUtil {

    public static String newAudioFilePath(Context context) {
        File dir = new File(context.getFilesDir(), "audio");
        if (!dir.exists()) dir.mkdirs();
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        return new File(dir, "entry_" + timestamp + ".m4a").getAbsolutePath();
    }
}
