package com.audiojournal.db;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.audiojournal.model.JournalEntry;
import java.util.List;

@Dao
public interface JournalEntryDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(JournalEntry entry);

    @Update
    void update(JournalEntry entry);

    @Delete
    void delete(JournalEntry entry);

    @Query("SELECT * FROM journal_entries ORDER BY createdAt DESC")
    LiveData<List<JournalEntry>> getAllEntries();

    @Query("SELECT * FROM journal_entries WHERE title LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%' OR notes LIKE '%' || :query || '%' ORDER BY createdAt DESC")
    LiveData<List<JournalEntry>> search(String query);

    @Query("SELECT * FROM journal_entries WHERE tags LIKE '%' || :tag || '%' ORDER BY createdAt DESC")
    LiveData<List<JournalEntry>> filterByTag(String tag);

    @Query("SELECT COUNT(*) FROM journal_entries")
    int getTotalCount();

    @Query("SELECT IFNULL(SUM(durationMs), 0) FROM journal_entries")
    long getTotalDurationMs();
}
