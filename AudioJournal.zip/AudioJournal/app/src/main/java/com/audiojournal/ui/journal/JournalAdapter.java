package com.audiojournal.ui.journal;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;
import com.audiojournal.R;
import com.audiojournal.model.JournalEntry;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class JournalAdapter extends ListAdapter<JournalEntry, JournalAdapter.EntryViewHolder> {

    private final Context context;
    private MediaPlayer mediaPlayer;
    private int playingPosition = -1;

    private static final DiffUtil.ItemCallback<JournalEntry> DIFF = new DiffUtil.ItemCallback<JournalEntry>() {
        @Override public boolean areItemsTheSame(@NonNull JournalEntry a, @NonNull JournalEntry b) {
            return a.getId() == b.getId();
        }
        @Override public boolean areContentsTheSame(@NonNull JournalEntry a, @NonNull JournalEntry b) {
            return a.getId() == b.getId() && a.getTitle().equals(b.getTitle());
        }
    };

    public JournalAdapter(Context context) {
        super(DIFF);
        this.context = context;
    }

    @NonNull
    @Override
    public EntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_journal_entry, parent, false);
        return new EntryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EntryViewHolder holder, int position) {
        holder.bind(getItem(position), position);
    }

    class EntryViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle, tvDate, tvDuration;
        ImageButton btnPlay;
        ChipGroup chipGroupTags;

        EntryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle       = itemView.findViewById(R.id.tv_entry_title);
            tvDate        = itemView.findViewById(R.id.tv_entry_date);
            tvDuration    = itemView.findViewById(R.id.tv_entry_duration);
            btnPlay       = itemView.findViewById(R.id.btn_play);
            chipGroupTags = itemView.findViewById(R.id.chip_group_entry_tags);
        }

        void bind(JournalEntry entry, int position) {
            tvTitle.setText(entry.getTitle());
            tvDuration.setText(entry.getFormattedDuration());

            SimpleDateFormat sdf = new SimpleDateFormat("MMM d, h:mm a", Locale.getDefault());
            tvDate.setText(sdf.format(new Date(entry.getCreatedAt())));

            chipGroupTags.removeAllViews();
            if (entry.getTags() != null && !entry.getTags().isEmpty()) {
                for (String tag : entry.getTags().split(",")) {
                    String trimmed = tag.trim();
                    if (trimmed.isEmpty()) continue;
                    Chip chip = new Chip(context);
                    chip.setText(trimmed);
                    chip.setClickable(false);
                    chipGroupTags.addView(chip);
                }
            }

            boolean isPlaying = playingPosition == position;
            btnPlay.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play);

            btnPlay.setOnClickListener(v -> {
                if (playingPosition == position) pausePlayback();
                else playEntry(entry, position);
            });
        }
    }

    private void playEntry(JournalEntry entry, int position) {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        int oldPosition = playingPosition;
        playingPosition = position;
        if (oldPosition >= 0) notifyItemChanged(oldPosition);
        notifyItemChanged(position);

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(entry.getAudioFilePath());
            mediaPlayer.prepare();
            mediaPlayer.start();
            mediaPlayer.setOnCompletionListener(mp -> {
                playingPosition = -1;
                notifyItemChanged(position);
            });
        } catch (IOException e) {
            e.printStackTrace();
            playingPosition = -1;
            notifyItemChanged(position);
        }
    }

    private void pausePlayback() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
        int old = playingPosition;
        playingPosition = -1;
        if (old >= 0) notifyItemChanged(old);
    }

    public void releasePlayer() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
