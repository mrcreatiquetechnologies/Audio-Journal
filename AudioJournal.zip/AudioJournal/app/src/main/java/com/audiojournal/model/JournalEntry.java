package com.audiojournal.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "journal_entries")
public class JournalEntry {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String title;
    private String audioFilePath;
    private long durationMs;
    private long createdAt;
    private String tags;
    private String notes;

    public JournalEntry() {}

    public long getId()              { return id; }
    public String getTitle()         { return title; }
    public String getAudioFilePath() { return audioFilePath; }
    public long getDurationMs()      { return durationMs; }
    public long getCreatedAt()       { return createdAt; }
    public String getTags()          { return tags; }
    public String getNotes()         { return notes; }

    public void setId(long id)                       { this.id = id; }
    public void setTitle(String title)               { this.title = title; }
    public void setAudioFilePath(String p)           { this.audioFilePath = p; }
    public void setDurationMs(long durationMs)       { this.durationMs = durationMs; }
    public void setCreatedAt(long createdAt)         { this.createdAt = createdAt; }
    public void setTags(String tags)                 { this.tags = tags; }
    public void setNotes(String notes)               { this.notes = notes; }

    public String getFormattedDuration() {
        long seconds = durationMs / 1000;
        long minutes = seconds / 60;
        seconds = seconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }
}
