package com.audiojournal.ui.stats;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.audiojournal.R;
import com.audiojournal.db.AppDatabase;
import java.util.concurrent.Executors;

public class StatsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_stats, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView tvTotal    = view.findViewById(R.id.tv_total_entries);
        TextView tvDuration = view.findViewById(R.id.tv_total_duration);

        Executors.newSingleThreadExecutor().execute(() -> {
            int count = AppDatabase.getInstance(requireContext()).journalEntryDao().getTotalCount();
            long totalMs = AppDatabase.getInstance(requireContext()).journalEntryDao().getTotalDurationMs();
            long totalMin = totalMs / 60000;

            requireActivity().runOnUiThread(() -> {
                tvTotal.setText(String.valueOf(count));
                tvDuration.setText(totalMin + "m");
            });
        });
    }
}
