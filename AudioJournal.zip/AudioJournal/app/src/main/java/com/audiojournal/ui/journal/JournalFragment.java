package com.audiojournal.ui.journal;

import android.os.Bundle;
import android.view.*;
import android.widget.SearchView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.audiojournal.R;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

public class JournalFragment extends Fragment {

    private JournalViewModel viewModel;
    private JournalAdapter adapter;
    private SearchView searchView;
    private ChipGroup chipGroupFilter;

    private static final String[] FILTER_TAGS = {"All", "Grateful", "Reflective", "Anxious", "Happy", "Work", "Personal"};

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_journal, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelProvider(this).get(JournalViewModel.class);

        RecyclerView recyclerView = view.findViewById(R.id.recycler_entries);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new JournalAdapter(requireContext());
        recyclerView.setAdapter(adapter);

        searchView = view.findViewById(R.id.search_view);
        chipGroupFilter = view.findViewById(R.id.chip_group_filter);

        buildFilterChips();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override public boolean onQueryTextSubmit(String q) { return false; }
            @Override public boolean onQueryTextChange(String q) {
                viewModel.setSearchQuery(q);
                return true;
            }
        });

        viewModel.getEntries().observe(getViewLifecycleOwner(), entries -> adapter.submitList(entries));
    }

    private void buildFilterChips() {
        for (String tag : FILTER_TAGS) {
            Chip chip = new Chip(requireContext());
            chip.setText(tag);
            chip.setCheckable(true);
            if (tag.equals("All")) chip.setChecked(true);
            chipGroupFilter.addView(chip);
            chip.setOnCheckedChangeListener((v, checked) -> {
                if (checked) viewModel.setTagFilter(tag.equals("All") ? null : tag);
            });
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (adapter != null) adapter.releasePlayer();
    }
}
