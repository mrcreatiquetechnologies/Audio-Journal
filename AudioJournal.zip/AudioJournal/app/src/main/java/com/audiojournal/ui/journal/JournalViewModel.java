package com.audiojournal.ui.journal;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.*;
import com.audiojournal.db.AppDatabase;
import com.audiojournal.db.JournalEntryDao;
import com.audiojournal.model.JournalEntry;
import java.util.List;

public class JournalViewModel extends AndroidViewModel {

    private final JournalEntryDao dao;
    private final MutableLiveData<String> searchQuery = new MutableLiveData<>("");
    private final MutableLiveData<String> tagFilter = new MutableLiveData<>(null);
    private final LiveData<List<JournalEntry>> entries;

    public JournalViewModel(@NonNull Application application) {
        super(application);
        dao = AppDatabase.getInstance(application).journalEntryDao();

        entries = Transformations.switchMap(tagFilter, tag ->
                Transformations.switchMap(searchQuery, query -> {
                    if (query != null && !query.isEmpty()) return dao.search(query);
                    if (tag != null && !tag.isEmpty()) return dao.filterByTag(tag);
                    return dao.getAllEntries();
                })
        );
    }

    public LiveData<List<JournalEntry>> getEntries() { return entries; }
    public void setSearchQuery(String query) { searchQuery.setValue(query); }
    public void setTagFilter(String tag) { tagFilter.setValue(tag); }
}
