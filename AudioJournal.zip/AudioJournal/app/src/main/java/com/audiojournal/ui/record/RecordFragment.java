package com.audiojournal.ui.record;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.audiojournal.R;
import com.audiojournal.db.AppDatabase;
import com.audiojournal.model.JournalEntry;
import com.audiojournal.util.AudioUtil;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class RecordFragment extends Fragment {

    private static final int REQUEST_RECORD_AUDIO = 1001;
    private static final String[] PRESET_TAGS = {"Grateful", "Reflective", "Anxious", "Happy", "Work", "Personal"};

    private MediaRecorder mediaRecorder;
    private boolean isRecording = false;
    private String currentFilePath;
    private long recordingStartTime;
    private long recordedDurationMs;

    private Button btnRecord;
    private TextView tvTimer, tvStatus;
    private EditText etTitle, etNotes;
    private ChipGroup chipGroupTags;
    private Button btnSave;
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private Runnable timerRunnable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_record, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        btnRecord     = view.findViewById(R.id.btn_record);
        tvTimer       = view.findViewById(R.id.tv_timer);
        tvStatus      = view.findViewById(R.id.tv_status);
        etTitle       = view.findViewById(R.id.et_title);
        etNotes       = view.findViewById(R.id.et_notes);
        chipGroupTags = view.findViewById(R.id.chip_group_tags);
        btnSave       = view.findViewById(R.id.btn_save);

        buildTagChips();

        btnRecord.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(requireActivity(),
                        new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
            } else {
                toggleRecording();
            }
        });

        btnSave.setOnClickListener(v -> saveEntry());
        btnSave.setEnabled(false);
    }

    private void buildTagChips() {
        for (String tag : PRESET_TAGS) {
            Chip chip = new Chip(requireContext());
            chip.setText(tag);
            chip.setCheckable(true);
            chipGroupTags.addView(chip);
        }
    }

    private void toggleRecording() {
        if (isRecording) stopRecording();
        else startRecording();
    }

    private void startRecording() {
        currentFilePath = AudioUtil.newAudioFilePath(requireContext());
        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setAudioSamplingRate(44100);
        mediaRecorder.setAudioEncodingBitRate(128000);
        mediaRecorder.setOutputFile(currentFilePath);
        try {
            mediaRecorder.prepare();
            mediaRecorder.start();
            isRecording = true;
            recordingStartTime = System.currentTimeMillis();
            btnRecord.setText("Stop");
            tvStatus.setText("Recording...");
            btnSave.setEnabled(false);
            startTimer();
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(requireContext(), "Failed to start recording", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopRecording() {
        if (mediaRecorder != null) {
            try { mediaRecorder.stop(); } catch (RuntimeException ignored) {}
            mediaRecorder.release();
            mediaRecorder = null;
        }
        isRecording = false;
        recordedDurationMs = System.currentTimeMillis() - recordingStartTime;
        stopTimer();
        btnRecord.setText("Record");
        tvStatus.setText("Recording complete. Save or discard.");
        btnSave.setEnabled(true);
    }

    private void startTimer() {
        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long elapsed = System.currentTimeMillis() - recordingStartTime;
                long secs = elapsed / 1000;
                tvTimer.setText(String.format("%d:%02d", secs / 60, secs % 60));
                timerHandler.postDelayed(this, 500);
            }
        };
        timerHandler.post(timerRunnable);
    }

    private void stopTimer() {
        if (timerRunnable != null) timerHandler.removeCallbacks(timerRunnable);
    }

    private void saveEntry() {
        JournalEntry entry = new JournalEntry();
        String title = etTitle.getText().toString().trim();
        entry.setTitle(title.isEmpty() ? "Untitled Entry" : title);
        entry.setAudioFilePath(currentFilePath);
        entry.setDurationMs(recordedDurationMs);
        entry.setCreatedAt(System.currentTimeMillis());
        entry.setNotes(etNotes.getText().toString().trim());
        entry.setTags(getSelectedTags());

        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase.getInstance(requireContext()).journalEntryDao().insert(entry);
            requireActivity().runOnUiThread(() -> {
                Toast.makeText(requireContext(), "Entry saved!", Toast.LENGTH_SHORT).show();
                resetForm();
            });
        });
    }

    private String getSelectedTags() {
        List<String> selected = new ArrayList<>();
        for (int i = 0; i < chipGroupTags.getChildCount(); i++) {
            Chip chip = (Chip) chipGroupTags.getChildAt(i);
            if (chip.isChecked()) selected.add(chip.getText().toString());
        }
        return String.join(",", selected);
    }

    private void resetForm() {
        etTitle.setText("");
        etNotes.setText("");
        tvTimer.setText("0:00");
        tvStatus.setText("Tap to start recording");
        btnSave.setEnabled(false);
        recordedDurationMs = 0;
        currentFilePath = null;
        for (int i = 0; i < chipGroupTags.getChildCount(); i++) {
            ((Chip) chipGroupTags.getChildAt(i)).setChecked(false);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (isRecording) stopRecording();
    }
}
