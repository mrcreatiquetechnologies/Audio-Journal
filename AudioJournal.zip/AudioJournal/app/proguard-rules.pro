# Keep Room entities
-keep class com.audiojournal.model.** { *; }
