# Audio Journal — Setup Guide

Everything is included in this ZIP. Layouts, themes, drawables, icons, manifest, and Gradle config are all done. **No throwaway-project trick needed.** Just open and run.

## Step 1 — Install Android Studio
Download from **developer.android.com/studio**. Run the installer. On first launch, accept defaults and let it download the SDK + emulator (~10–20 min).

## Step 2 — Open the project
1. Unzip somewhere permanent (e.g. `Documents/AndroidProjects/AudioJournal`)
2. Android Studio → **Open** → pick the `AudioJournal` folder → OK
3. When it asks "Trust this project?" → **Trust Project**

## Step 3 — Wait for Gradle sync
- A status bar appears at the bottom: "Gradle sync in progress…"
- Android Studio will auto-download Gradle 8.7 + all dependencies. **First sync takes 5–15 min.**
- **If it complains about a missing `gradle-wrapper.jar`:** open a terminal in the project folder (View → Tool Windows → Terminal in Android Studio) and run `gradle wrapper --gradle-version 8.7` once. Android Studio usually does this automatically — only run manually if sync fails on this specific error.
- If you get a JDK error: **File → Settings → Build → Build Tools → Gradle → Gradle JDK → Embedded JDK (17)** → Apply → re-sync.
- If sync fails for any other reason: click **"Try Again"** in the notification at the top.

## Step 4 — Connect a device or start emulator

**Physical phone (faster):**
1. Phone: Settings → About phone → tap Build number 7 times
2. Settings → Developer options → enable USB debugging
3. Plug in via USB → tap Allow on the prompt
4. Phone shows up in the device dropdown (top toolbar)

**Emulator:**
1. Tools → Device Manager → Create Virtual Device → Pixel 7 → API 34 → Finish
2. Click ▶ next to the virtual device

## Step 5 — Run the app
1. Pick your device in the top toolbar dropdown
2. Click the green **▶ Run** button (or Shift+F10)
3. Wait 2–5 min for the first build
4. App launches → grant the microphone permission when prompted

## Step 6 — Build a shareable APK
Once the dev build works:
1. **Build → Generate Signed Bundle / APK → APK → Next**
2. Click **Create new** keystore
   - Path: `keystore/audiojournal.jks` (anywhere is fine)
   - Set a strong password — **save it**, you need it for every future update
   - Fill in name + organization (any values)
3. Pick **release** variant → **Finish**
4. APK lands at `app/build/outputs/apk/release/app-release.apk`
5. Transfer to any Android phone, install (enable "Install from unknown sources" first)

## Common errors and fixes

| Error | Fix |
|-------|-----|
| `SDK location not found` | Tools → SDK Manager → install SDK Platform 34 |
| `Unsupported Java version` | Settings → Build → Gradle → JDK → Embedded JDK 17 |
| `Failed to install on emulator` | Wipe emulator data (Device Manager → ⋮ → Wipe Data) |
| `Resource not found` errors | Build → Clean Project, then Build → Rebuild Project |
| App crashes on Record | Make sure microphone permission is granted in app settings |

## Project structure (FYI)
```
AudioJournal/
├── app/
│   ├── build.gradle              # dependencies
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/audiojournal/    # all Java code
│       └── res/
│           ├── drawable/         # icons (play, pause, mic, list, stats)
│           ├── layout/           # 4 XML layouts
│           ├── menu/             # bottom nav
│           ├── mipmap-anydpi-v26/ # adaptive launcher icon
│           ├── values/           # strings, colors, themes
│           └── values-night/     # dark mode theme
├── build.gradle                  # root
├── settings.gradle
├── gradle.properties
├── gradle/wrapper/               # gradle-wrapper.properties
└── README.md
```

## What's next
Once you've got it running, ideas for v2:
- Live waveform visualization while recording (use `MediaRecorder.getMaxAmplitude()`)
- Swipe-to-delete entries
- Edit existing entries
- Export all entries as a ZIP backup
- Cloud sync via Firebase
